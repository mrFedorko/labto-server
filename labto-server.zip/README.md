# EXPRESS-NODE-MONGO_DB server

##Requirements

1. Remote running database (Mongo_DB) with admin user and current db user
2. NodeJs 16^

## Get started

Create ".env" file to start working 

