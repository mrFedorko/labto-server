export const allowedIps = [
    '::1',
]