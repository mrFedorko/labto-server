import { Router } from 'express';
import { handleDeleteOrder, handleGetMyOrders, handleGetOrders, handleMessageOrder, handleNewOrder, handleStatusOrder } from '../controllers/orderController.js';

const orderRouter = Router();

orderRouter.post(
    '/create/',
    handleNewOrder
);
orderRouter.patch(
    '/status/:target/:status/',
    handleStatusOrder
);
orderRouter.delete(
    '/delete/:target/',
    handleDeleteOrder
);
orderRouter.put(
    '/message/:target/',
    handleMessageOrder
);
orderRouter.get(
    '/getMy/',
    handleGetMyOrders
);
orderRouter.get(
    '/geaAll/:status/',
    handleGetOrders
);


export {orderRouter}