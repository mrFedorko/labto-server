import User from "../models/User";

export const handleIsStart = async () => {
    try {
        const users = await User.find({});
        if(users.length) return res.json({start:false})
        return res.json({start: true})
    } catch (error) {
        console.log(error)
        res.status(500)
        .json({
            message: 'server side error', 
            clientMessage: 'Ошибка сервера',
        });
    }
}

export const handleStart = async () => {
        
    try {
        const users = await User.find({});
        if(users.length) return res.sendStatus(403)
        const { email, password } = req.body;
        if(!(email && password)){
            return res.status(400).json({message: 'error', clientMessage: 'Ошибка. Не все данные заполнены'})
        }
        const hashedPassword = await bcrypt.hash(password, 6);

        const newUser = new User({email, password: hashedPassword, role: 'admin'})
        await newUser.save();
        res.json({message: 'success', clientMessage: 'Стартовый профиль создан. Теперь войдите, используя введенные данные'})
    } catch (error) {
        console.log(error)
        res.status(500)
        .json({
            message: 'server side error', 
            clientMessage: 'Ошибка сервера',
        });
    }
}