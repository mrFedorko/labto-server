import { Schema, model, Types } from 'mongoose';

const orderSchema = new Schema({
    name: {type: String, require: true},
    type: {type: String, default: ''},
    text: {type: String, default: ''},
    status: {type: String, default: 'created'},
    fromDate: {type: Date, default: Date.now()},
    messages: [{
        from: String,
        date: {type: Date, default: Date.now()},
        text: String
    }],
    owner: {type: Types.ObjectId, ref: 'User'},
    addressee: Types.ObjectId,
    archive: {type: Boolean, default: false},
});

const Order = model('Order', orderSchema);



export default Order;
